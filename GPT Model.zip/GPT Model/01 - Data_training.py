import time
import openai
from openai import OpenAI

# Initialize the client
# openai.api_key = "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"
openai.api_key = "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"
client = OpenAI(api_key=openai.api_key)

# Add error handling for file upload
try: 
    upload_response = client.files.create(
        file=open("FinalData2804.jsonl", "rb"),
        purpose="fine-tune"
    )
    training_file_id = upload_response.id
    print(f"✅ Uploaded training file: {training_file_id}")
except Exception as e:
    print(f"❌ File upload failed: {str(e)}")
    exit(1)

# Fine-tune the model
fine_tune_response = client.fine_tuning.jobs.create(
    training_file=training_file_id,
    model="gpt-3.5-turbo",  # Updated to the correct model name
     hyperparameters={
        "n_epochs": 10,                     # or 12
        "learning_rate_multiplier": 0.05,   # lower for quality
        "batch_size": 4,                    # small dataset
    }
)

fine_tune_job_id = fine_tune_response.id
print(f"🚀 Fine-tuning job started: {fine_tune_job_id}")

# Step 3: Monitor job status
# Add timeout for status monitoring
max_wait_time = 10800  # 3 hours
start_time = time.time()
while True:
    status_response = client.fine_tuning.jobs.retrieve(fine_tune_job_id)
    status = status_response.status
    print(f"📡 Status: {status}")
    if status in ["succeeded", "failed"]:
        break
    if time.time() - start_time > max_wait_time:
        print("❌ Timeout: Fine-tuning took too long")
        break
    time.sleep(30)

# Step 4: Get model ID if successful
if status == "succeeded":
    fine_tuned_model = status_response.fine_tuned_model
    print(f"🎉 Fine-tuned model is ready: {fine_tuned_model}")
else:
    print("❌ Fine-tuning failed. Check logs.")

# Optional: Show training logs
events = client.fine_tuning.jobs.list_events(id=fine_tune_job_id)
print("\n📜 Training Logs:")
for event in events.data:
    print(f"- {event.message}") 