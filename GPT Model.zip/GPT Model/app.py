import os
import time
import json
import streamlit as st
import openai
from openai import OpenAI

# ✅ Set API key and initialize OpenAI client
# openai.api_key = "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"
openai.api_key = "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"

client = OpenAI(api_key=openai.api_key)

# ✅ Streamlit app configuration
st.set_page_config(layout="wide", page_title="IK-Society Chatbot")
st.image("http://iksociety.org/wp-content/uploads/2020/09/logo-new.jpg", width=100)
st.title("IK-Society Chat GPT")

# ✅ Typing effect function
def type_response(response_text):
    message_placeholder = st.empty()
    full_text = ""
    chunks = response_text.split('. ')  # Split by sentences

    for chunk in chunks:
        if not chunk.endswith('.'):
            chunk += '.'
        full_text += chunk + " "
        message_placeholder.markdown(full_text + "▌")  # Typing cursor
        time.sleep(0.4)

    message_placeholder.markdown(full_text.strip())

# ✅ Save chat to a local file
def save_chat():
    with open("chat_history.json", "w") as f:
        json.dump(st.session_state.messages, f)

# ✅ Load saved chat from file
def load_chat():
    try:
        with open("chat_history.json", "r") as f:
            st.session_state.messages = json.load(f)
    except FileNotFoundError:
        st.session_state.messages = [{"role": "assistant", "content": "No saved chat history found."}]

# ✅ Initialize message history
if "messages" not in st.session_state:
    st.session_state.messages = []

# ✅ Sidebar controls
with st.sidebar:
    st.title("GPT Controls")

    if st.button("📁 Load Saved Chat"):
        load_chat()

    if st.button("💾 Save Chat"):
        save_chat()

    if st.button("🧹 New Chat"):
        st.session_state.messages = []
        st.success("Chat cleared.")

# ✅ Chatbot response handler
def chatbot(messages):
    try:
        response = client.chat.completions.create(
            model="ft:gpt-3.5-turbo-0125:designlab-international::BRFXVuYy",
            messages=[
                {"role": "system", "content": """You are an IK-Society chatbot. When answering:
                1. Match keywords or partial questions to training data
                2. Only fetch answers from the given data, don't fetch data from web or any other external source
                3. Only use information from the training data
                4. If multiple training examples are relevant, combine them
                5. If information isn't in training data, say "I don't have that information"
                6. Provide engaging response like \' Let me know if you want more information \'
                7. Always give answers that are at least 3-4 sentences long, detailed, and engaging
                8. For unrelated questions: "I apologize, but I can only assist with questions related to IK-Society's educational institutions.\""""}
            ] + messages,
            temperature=0.3
        )
        return response.choices[0].message.content
    except Exception as e:
        print(f"Error: {str(e)}")
        return f"An error occurred: {str(e)}"

# ✅ Display chat history
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# ✅ Chat input and handling
prompt = st.chat_input("Ask your question about IK-Society...")
if prompt:
    # User message
    user_message = {"role": "user", "content": prompt}
    st.session_state.messages.append(user_message)

    with st.chat_message("user"):
        st.markdown(prompt)

    # Get assistant reply
    response = chatbot(st.session_state.messages)
    assistant_message = {"role": "assistant", "content": response}
    st.session_state.messages.append(assistant_message)

    with st.chat_message("assistant"):
        type_response(response)

# Old Models
# ft:gpt-3.5-turbo-0125:designlab-international::BM9jPNRS
# ft:gpt-3.5-turbo-0125:designlab-international::BMuqvM7B /- Final_Data
# ft:gpt-3.5-turbo-0125:designlab-international::BRCkUbyL /- File2804
# ft:gpt-3.5-turbo-0125:designlab-international::BRFXVuYy /- Final_Data2804